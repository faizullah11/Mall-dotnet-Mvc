﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using PakMall.Models;

namespace PakMall.Controllers
{
    public class UserItemController : Controller
    {
        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: PakMall
        /* public ActionResult Index()
         {
             return View(db.UserItems.ToList());
         }*/

        
    //GEt: PakMall

    public ActionResult Index(string discription, string searchString)
        {
            var DiscriptionLst = new List<string>();

            var DiscriptionQry = from d in db.UserItems
                                 orderby d.Discription
                                 select d.Discription;

            DiscriptionLst.AddRange(DiscriptionQry.Distinct());
            ViewBag.discription = new SelectList(DiscriptionLst);

            var userItems = from m in db.UserItems
                            select m;

            if (!String.IsNullOrEmpty(searchString))
            {
                userItems = userItems.Where(s => s.Title.Contains(searchString));
            }



            if (!string.IsNullOrEmpty(discription))
            {
                userItems = userItems.Where(x => x.Discription == discription);
            }

            return View(userItems);
        }
        // GET: PakMall/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserItem userItem = db.UserItems.Find(id);
            if (userItem == null)
            {
                return HttpNotFound();
            }
            return View(userItem);
        }

        public ViewResult About()
        {
            return View();
        }

        // GET: PakMall/Create
        public ActionResult Create()
        {
            return View();
        }

        public ViewResult Contact()
        {
            return View();
        }

        // POST: PakMall/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,Title,ManufacturingDate,Discription,Price,itemimage,Contact,Email")] UserItem userItem)
        {
            if (ModelState.IsValid)
            {
                if (userItem.Email != null || userItem.Contact != null)
                {
                    db.UserItems.Add(userItem);
                    db.SaveChanges();
                }
                return RedirectToAction("Index");
            }

            return View(userItem);
        }




        // GET: PakMall/Edit/5
       // [Authorize]
        public ActionResult Edit(int? id)
        {


            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            UserItem userItem = db.UserItems.Find(id);
            if (userItem == null)
            {
                return HttpNotFound();
            }

            return View(userItem);

        }

        // POST: PakMall/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        
        [HttpPost]
        [ValidateAntiForgeryToken]
       
        public ActionResult Edit([Bind(Include = "ID,Title,ManufacturingDate,Discription,Price,itemImage,Contact,Email")] UserItem userItem)
        {

          
            ApplicationUser user = db.Users.FirstOrDefault(x => x.Email == userItem.Email);
            if (user != null)
            {
                if (ModelState.IsValid)
                {
                    db.Entry(userItem).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            else
            { return HttpNotFound(); }
            return View(userItem);
        }

        // GET: PakMall/Delete/5
        //    [Authorize]
     //   [HttpPost]
      //  [ValidateAntiForgeryToken]
        public ActionResult Delete(int? id)
        {
              
       
            
            if (id == null )
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                UserItem userItem = db.UserItems.Find(id);
                string emailProduct= userItem.Email;
            //   ApplicationUser user = db.Users.FirstOrDefault(x => x.Email == emailCheck);
            ApplicationUser user = HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>().FindById(User.Identity.GetUserId());

            if (emailProduct==null ) { return View(userItem); }
            string currentEm = user.Email;
            if (currentEm == null) { return View(userItem); }
            if (emailProduct != currentEm)
            { return HttpNotFound(); }
          
            
            if (userItem == null)
                {
                    return HttpNotFound();
                }
            
                return View(userItem);
            
        }

        // POST: PakMall/Delete/5
    //    [Authorize]
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            UserItem userItem = db.UserItems.Find(id);
        
            {
                db.UserItems.Remove(userItem);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}