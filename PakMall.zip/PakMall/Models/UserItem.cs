﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;


namespace PakMall.Models
{
    public class UserItem
    {

        public int ID { get; set; }
        public string Title { get; set; }
        public DateTime ManufacturingDate { get; set; }
        public string Discription { get; set; }
        public decimal Price { get; set; }
        public byte[] itemImage { get; set; }
    
       
        public string Contact { get; set; }
        public String Email { get; set; }
    }

    public class PakMallDBContext : DbContext
    {
        public PakMallDBContext()
       : base("DefaultConnection") // <-- this is what i added.
        {
        }

        public DbSet<UserItem> UserItems { get; set; }
    }
}